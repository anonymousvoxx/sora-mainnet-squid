export enum OrderBookStatus {
    Trade = "Trade",
    PlaceAndCancel = "PlaceAndCancel",
    OnlyCancel = "OnlyCancel",
    Stop = "Stop",
}
