export enum SnapshotType {
    DEFAULT = "DEFAULT",
    HOUR = "HOUR",
    DAY = "DAY",
    MONTH = "MONTH",
}
