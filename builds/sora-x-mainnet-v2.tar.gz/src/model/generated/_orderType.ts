export enum OrderType {
    Limit = "Limit",
    Market = "Market",
}
