export enum HistoryElementType {
    CALL = "CALL",
    EVENT = "EVENT",
}
