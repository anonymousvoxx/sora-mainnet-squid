export enum PayeeType {
    STAKED = "STAKED",
    STASH = "STASH",
    CONTROLLER = "CONTROLLER",
    ACCOUNT = "ACCOUNT",
    NONE = "NONE",
}
