export enum OrderStatus {
    Active = "Active",
    Aligned = "Aligned",
    Canceled = "Canceled",
    Expired = "Expired",
    Filled = "Filled",
}
