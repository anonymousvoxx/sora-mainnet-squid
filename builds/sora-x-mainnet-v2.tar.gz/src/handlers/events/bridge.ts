import { BlockContext, Event } from '../../types'
import { getEventData } from '../../utils/entities'
import { events } from '../../types/generated/merged'
import { createHistoryElement } from '../../utils/history'
import { logStartProcessingEvent } from '../../utils/logs'


export async function xcmPalletAttemptedHandler(
	ctx: BlockContext,
	event: Event<'XcmPallet.Attempted'>
): Promise<void> {
    ctx.log.info('start indexing XcmPallet.Attempted')
	logStartProcessingEvent(ctx, event)

  // const type = events.xcmPallet.attempted
	// const data = getEventData(ctx, type, event)
}

export async function messageAcceptedHandler(
	ctx: BlockContext,
	event: Event<'SubstrateBridgeOutboundChannel.MessageAccepted'>
): Promise<void> {
	logStartProcessingEvent(ctx, event)

  const type = events.substrateBridgeOutboundChannel.messageAccepted
	const data = getEventData(ctx, type, event)

  const networkId = 'networkId' in data ? data.networkId : data[0]
  const batchNonce = 'batchNonce' in data ? data.batchNonce.toString() : null
  const messageNonce = 'messageNonce' in data ? data.messageNonce.toString() : null

	const historyData = {
    networkId: networkId.__kind,
    batchNonce,
    messageNonce
  }

	createHistoryElement(ctx, event, historyData)
}



